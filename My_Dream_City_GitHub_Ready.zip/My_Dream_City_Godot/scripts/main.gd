extends Node3D
## My Dream City - mobile-first 3D city-builder foundation.
## Procedural low-poly buildings keep the first project asset-free and lightweight.

const CELL := 8.0
const SAVE_PATH := "user://my_dream_city_save.json"
const BUILDING_TYPES := [
    {"id":"house","label":"House","color":Color("#e6c69b"),"height":5.0},
    {"id":"villa","label":"Luxury Villa","color":Color("#e8dfca"),"height":7.0},
    {"id":"apartment","label":"Apartment","color":Color("#9bb9d5"),"height":19.0},
    {"id":"skyscraper","label":"Skyscraper","color":Color("#7fa9c9"),"height":42.0},
    {"id":"office","label":"Office Tower","color":Color("#8da9b8"),"height":30.0},
    {"id":"factory","label":"Factory","color":Color("#929da5"),"height":10.0},
    {"id":"school","label":"School","color":Color("#d9c38e"),"height":8.0},
    {"id":"hospital","label":"Hospital","color":Color("#e9eeee"),"height":12.0},
    {"id":"police","label":"Police Station","color":Color("#7e9fbd"),"height":7.0},
    {"id":"fire","label":"Fire Station","color":Color("#c96f5f"),"height":7.0},
    {"id":"mall","label":"Shopping Mall","color":Color("#b99bc8"),"height":12.0},
    {"id":"station","label":"Railway Station","color":Color("#d0b78f"),"height":9.0}
]

var buildings: Array[Dictionary] = []
var selected_type := 0
var erase_mode := false
var camera_yaw := 0.7
var camera_pitch := -0.72
var camera_distance := 95.0
var drag_start := Vector2.ZERO
var last_touch := Vector2.ZERO
var touch_points: Dictionary = {}
var ground: MeshInstance3D
var camera: Camera3D
var world: Node3D
var ui: CanvasLayer
var status_label: Label
var inventory_box: HBoxContainer

func _ready() -> void:
    _make_environment()
    _make_world()
    _make_camera()
    _make_ui()
    _load_city()
    _refresh_camera()
    _update_status()

func _make_environment() -> void:
    var env := WorldEnvironment.new()
    var e := Environment.new()
    e.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    var sky_mat := ProceduralSkyMaterial.new()
    sky_mat.sky_top_color = Color("#4d8bb8")
    sky_mat.sky_horizon_color = Color("#c6e2e8")
    sky_mat.ground_bottom_color = Color("#465c45")
    sky_mat.ground_horizon_color = Color("#a6bd91")
    sky.sky_material = sky_mat
    e.sky = sky
    e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    e.ambient_light_color = Color("#c4d7e5")
    e.ambient_light_energy = 0.8
    e.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.environment = e
    add_child(env)
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -32, 0)
    sun.light_energy = 1.25
    sun.shadow_enabled = true
    add_child(sun)

func _make_world() -> void:
    world = Node3D.new()
    world.name = "CityWorld"
    add_child(world)
    var plane := MeshInstance3D.new()
    var pm := PlaneMesh.new()
    pm.size = Vector2(2000, 2000)
    plane.mesh = pm
    plane.position.y = -0.15
    var grass := StandardMaterial3D.new()
    grass.albedo_color = Color("#78a66e")
    grass.roughness = 1.0
    plane.material_override = grass
    world.add_child(plane)
    _make_grid()

func _make_grid() -> void:
    var im := ImmediateMesh.new()
    im.surface_begin(Mesh.PRIMITIVE_LINES)
    var extent := 400.0
    for i in range(-50, 51):
        var p := float(i) * CELL
        im.surface_add_vertex(Vector3(p, 0.015, -extent))
        im.surface_add_vertex(Vector3(p, 0.015, extent))
        im.surface_add_vertex(Vector3(-extent, 0.015, p))
        im.surface_add_vertex(Vector3(extent, 0.015, p))
    im.surface_end()
    var lines := MeshInstance3D.new()
    lines.mesh = im
    var mat := StandardMaterial3D.new()
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.albedo_color = Color(0.85, 0.95, 0.82, 0.25)
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    lines.material_override = mat
    world.add_child(lines)

func _make_camera() -> void:
    camera = Camera3D.new()
    camera.current = true
    camera.fov = 55.0
    add_child(camera)

func _refresh_camera() -> void:
    var target := Vector3.ZERO
    var horizontal := camera_distance * cos(camera_pitch)
    var pos := target + Vector3(sin(camera_yaw) * horizontal,
        -camera_distance * sin(camera_pitch),
        cos(camera_yaw) * horizontal)
    camera.position = pos
    camera.look_at(target, Vector3.UP)

func _make_ui() -> void:
    ui = CanvasLayer.new()
    add_child(ui)
    var root_ui := Control.new()
    root_ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    ui.add_child(root_ui)

    var top := PanelContainer.new()
    top.position = Vector2(14, 12)
    top.custom_minimum_size = Vector2(260, 70)
    root_ui.add_child(top)
    var top_col := VBoxContainer.new()
    top.add_child(top_col)
    var title := Label.new()
    title.text = "🏙 MY DREAM CITY"
    title.add_theme_font_size_override("font_size", 20)
    top_col.add_child(title)
    status_label = Label.new()
    status_label.text = "∞ Coins  |  ∞ Keys"
    top_col.add_child(status_label)

    var hint := Label.new()
    hint.text = "Drag: rotate camera  •  Pinch: zoom  •  Tap ground: build"
    hint.anchor_left = 0.5
    hint.anchor_right = 0.5
    hint.position = Vector2(-250, 92)
    hint.custom_minimum_size = Vector2(500, 28)
    hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    root_ui.add_child(hint)

    var bottom := PanelContainer.new()
    bottom.anchor_left = 0.0
    bottom.anchor_right = 1.0
    bottom.anchor_top = 1.0
    bottom.anchor_bottom = 1.0
    bottom.offset_left = 10
    bottom.offset_right = -10
    bottom.offset_top = -112
    bottom.offset_bottom = -10
    root_ui.add_child(bottom)
    var col := VBoxContainer.new()
    bottom.add_child(col)
    inventory_box = HBoxContainer.new()
    inventory_box.add_theme_constant_override("separation", 6)
    col.add_child(inventory_box)
    for i in range(BUILDING_TYPES.size()):
        var b := Button.new()
        b.text = str(BUILDING_TYPES[i]["label"])
        b.custom_minimum_size = Vector2(88, 42)
        b.pressed.connect(_select_building.bind(i))
        inventory_box.add_child(b)
    var actions := HBoxContainer.new()
    col.add_child(actions)
    var erase_btn := Button.new()
    erase_btn.text = "Demolish: OFF"
    erase_btn.pressed.connect(_toggle_erase)
    actions.add_child(erase_btn)
    var save_btn := Button.new()
    save_btn.text = "Save City"
    save_btn.pressed.connect(_save_city)
    actions.add_child(save_btn)
    var load_btn := Button.new()
    load_btn.text = "Load City"
    load_btn.pressed.connect(_load_city)
    actions.add_child(load_btn)

func _select_building(index: int) -> void:
    selected_type = clampi(index, 0, BUILDING_TYPES.size() - 1)
    erase_mode = false
    _update_status()

func _toggle_erase() -> void:
    erase_mode = not erase_mode
    _update_status()

func _update_status() -> void:
    if status_label:
        var item: Dictionary = BUILDING_TYPES[selected_type]
        status_label.text = "∞ Coins  |  ∞ Keys  |  " + str(buildings.size()) + " placed"
        if erase_mode:
            status_label.text += "  |  DEMOLISH"

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            touch_points[event.index] = event.position
            drag_start = event.position
            last_touch = event.position
        else:
            if touch_points.size() <= 1:
                _try_place(event.position)
            touch_points.erase(event.index)
    elif event is InputEventScreenDrag:
        if touch_points.size() >= 2:
            var old_dist := _touch_distance()
            touch_points[event.index] = event.position
            var new_dist := _touch_distance()
            if old_dist > 0.0:
                camera_distance = clampf(camera_distance * old_dist / maxf(new_dist, 1.0), 22.0, 240.0)
            _refresh_camera()
        else:
            camera_yaw -= event.relative.x * 0.008
            camera_pitch = clampf(camera_pitch - event.relative.y * 0.006, -1.25, -0.2)
            _refresh_camera()
        touch_points[event.index] = event.position
    elif event is InputEventMouseButton and event.pressed:
        if event.button_index == MOUSE_BUTTON_WHEEL_UP:
            camera_distance = maxf(22.0, camera_distance * 0.9)
            _refresh_camera()
        elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
            camera_distance = minf(240.0, camera_distance * 1.1)
            _refresh_camera()
        elif event.button_index == MOUSE_BUTTON_LEFT:
            _try_place(event.position)
    elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
        camera_yaw -= event.relative.x * 0.008
        camera_pitch = clampf(camera_pitch - event.relative.y * 0.006, -1.25, -0.2)
        _refresh_camera()

func _touch_distance() -> float:
    if touch_points.size() < 2:
        return 0.0
    var vals: Array = touch_points.values()
    return vals[0].distance_to(vals[1])

func _try_place(screen_pos: Vector2) -> void:
    var from := camera.project_ray_origin(screen_pos)
    var dir := camera.project_ray_normal(screen_pos)
    var plane := Plane(Vector3.UP, 0.0)
    var hit = plane.intersects_ray(from, dir)
    if hit == null:
        return
    var cell_x := roundi(hit.x / CELL)
    var cell_z := roundi(hit.z / CELL)
    var key := Vector2i(cell_x, cell_z)
    var existing := _find_building(key)
    if erase_mode:
        if existing >= 0:
            var node_name := str(buildings[existing]["node"])
            var node := world.get_node_or_null(NodePath(node_name))
            if node:
                node.queue_free()
            buildings.remove_at(existing)
            _update_status()
        return
    if existing >= 0:
        return
    var data: Dictionary = BUILDING_TYPES[selected_type]
    var pos := Vector3(float(cell_x) * CELL, 0, float(cell_z) * CELL)
    var node := _create_building(data, pos)
    world.add_child(node)
    buildings.append({"x":cell_x, "z":cell_z, "type":selected_type, "node":node.name})
    _update_status()

func _find_building(cell: Vector2i) -> int:
    for i in range(buildings.size()):
        if int(buildings[i]["x"]) == cell.x and int(buildings[i]["z"]) == cell.y:
            return i
    return -1

func _create_building(data: Dictionary, pos: Vector3) -> Node3D:
    var root_node := Node3D.new()
    root_node.name = "Building_%d_%d_%d" % [int(pos.x / CELL), int(pos.z / CELL), randi() % 100000]
    root_node.position = pos
    var height := float(data["height"])
    var mesh := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = Vector3(5.5, height, 5.5)
    mesh.mesh = box
    mesh.position.y = height * 0.5
    var mat := StandardMaterial3D.new()
    mat.albedo_color = data["color"]
    mat.roughness = 0.72
    mesh.material_override = mat
    root_node.add_child(mesh)
    # Roof cap and simple repeated window bands.
    var roof := MeshInstance3D.new()
    var roof_mesh := BoxMesh.new()
    roof_mesh.size = Vector3(5.8, 0.35, 5.8)
    roof.mesh = roof_mesh
    roof.position.y = height + 0.17
    var roof_mat := StandardMaterial3D.new()
    roof_mat.albedo_color = data["color"].darkened(0.18)
    roof.material_override = roof_mat
    root_node.add_child(roof)
    if height > 9.0:
        for floor_index in range(1, int(height / 4.0)):
            var band := MeshInstance3D.new()
            var band_mesh := BoxMesh.new()
            band_mesh.size = Vector3(5.58, 0.12, 5.58)
            band.mesh = band_mesh
            band.position.y = float(floor_index) * 4.0
            var band_mat := StandardMaterial3D.new()
            band_mat.albedo_color = Color("#b8d7df")
            band_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
            band_mat.albedo_color.a = 0.45
            band.material_override = band_mat
            root_node.add_child(band)
    return root_node

func _save_city() -> void:
    var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if file == null:
        return
    file.store_string(JSON.stringify({"buildings":buildings}))
    file.close()
    _update_status()

func _load_city() -> void:
    if not FileAccess.file_exists(SAVE_PATH):
        return
    var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
    if file == null:
        return
    var parsed = JSON.parse_string(file.get_as_text())
    file.close()
    if typeof(parsed) != TYPE_DICTIONARY:
        return
    for child in world.get_children():
        if child is Node3D and child.name.begins_with("Building_"):
            child.queue_free()
    buildings.clear()
    for entry in parsed.get("buildings", []):
        var idx := clampi(int(entry.get("type", 0)), 0, BUILDING_TYPES.size() - 1)
        var pos := Vector3(float(entry.get("x", 0)) * CELL, 0, float(entry.get("z", 0)) * CELL)
        var node := _create_building(BUILDING_TYPES[idx], pos)
        world.add_child(node)
        buildings.append({"x":int(entry.get("x",0)), "z":int(entry.get("z",0)), "type":idx, "node":node.name})
    _update_status()
