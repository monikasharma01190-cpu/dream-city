# My Dream City — Godot 4 Android starter

A free, personal-use, mobile-first 3D city-builder starter project.

## Features in this starter
- 3D ground, sky, sunlight and build grid
- Touch-drag orbit camera and pinch zoom
- Procedural building placement: house, villa, apartment, skyscraper, office, factory, school, hospital, police, fire, mall and railway station
- Demolish mode
- Local save/load
- Unlimited-resource UI concept

## Open and run on Android
1. Install the official Godot Android Editor: https://godotengine.org/download/android/
2. Extract this repository/ZIP to your phone.
3. In Godot Android Editor, import the `project.godot` file.
4. Press Run.

## Build APK using GitHub Actions
1. Create a GitHub repository named `My-Dream-City`.
2. Upload all files and folders from this project, including `.github/workflows/android-apk.yml`.
3. Open the repository's **Actions** tab.
4. Select **Build Android APK** and press **Run workflow** (or push to `main`).
5. When the run finishes, open the successful run and download the `My-Dream-City-Android-APK` artifact.

The workflow uses a Godot CI container and is a best-effort starter. If the Godot container's Android export templates or SDK configuration change, the workflow may need adjustment. The project must have a valid Android export preset named `Android` in Godot before a successful APK export. Configure this once in Godot's Export menu if the editor does not create the preset automatically, then commit `export_presets.cfg` (do not add signing secrets for a debug-only personal APK).

## Current scope and honest status
This is a starter foundation, not the requested finished simulator. It currently has simple procedural 3D building blocks and basic touch camera/build/save controls. Detailed high-quality 3D assets, roads and bridges, moving cars/buses/trains/aircraft, airports/metro systems, streaming world expansion, and extensive mobile performance optimization remain development tasks. The APK workflow is included as a starting point; no APK is built or tested by this package itself.

## Free tools
- Godot: https://godotengine.org/
- Blender: https://www.blender.org/
- GitHub Actions: https://docs.github.com/en/actions
